package com.example.meowverse;

public class Users {
    String parentName, catName, catAgeInMonths, catGender;

    public Users(String parentName, String catName, String catAgeInMonths, String catGender) {
        this.parentName = parentName;
        this.catName = catName;
        this.catAgeInMonths = catAgeInMonths;
        this.catGender = catGender;
    }

    public Users() {
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public String getCatAgeInMonths() {
        return catAgeInMonths;
    }

    public void setCatAgeInMonths(String catAgeInMonths) {
        this.catAgeInMonths = catAgeInMonths;
    }

    public String getCatGender() {
        return catGender;
    }

    public void setCatGender(String catGender) {
        this.catGender = catGender;
    }
}

package com.example.meowverse;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.meowverse.databinding.ProfileActivityBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ProfileActivity extends AppCompatActivity {

    ProfileActivityBinding binding;
    FirebaseDatabase db;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ProfileActivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = FirebaseDatabase.getInstance();
        reference = db.getReference("CatProfiles");

        binding.btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String parentName = binding.parentsname.getText().toString().trim();
                String catName = binding.catsname.getText().toString().trim();
                String gender = binding.gender.getText().toString().trim().toLowerCase();
                String catAge = binding.catage.getText().toString().trim();

                String nameRegex = "^[a-zA-Z ]+$";
                String ageRegex = "^[0-9]+$";

                if (parentName.isEmpty() || !parentName.matches(nameRegex)) {
                    binding.parentsname.setError("Please enter a valid parent's name");
                    binding.parentsname.requestFocus();
                    return;
                }

                if (catName.isEmpty() || !catName.matches(nameRegex)) {
                    binding.catsname.setError("Please enter a valid cat name");
                    binding.catsname.requestFocus();
                    return;
                }

                if (gender.isEmpty() || (!gender.equals("male") && !gender.equals("female"))) {
                    binding.gender.setError("Gender must be 'male' or 'female'");
                    binding.gender.requestFocus();
                    return;
                }

                if (catAge.isEmpty() || !catAge.matches(ageRegex)) {
                    binding.catage.setError("Please enter a valid numeric age");
                    binding.catage.requestFocus();
                    return;
                }

                // All validations passed — save to Firebase
                Users profile = new Users(parentName, catName, gender, catAge);

                reference.child(catName).setValue(profile).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(ProfileActivity.this, "Profile saved successfully!", Toast.LENGTH_SHORT).show();
                            binding.parentsname.setText("");
                            binding.catsname.setText("");
                            binding.gender.setText("");
                            binding.catage.setText("");

                            Intent intent = new Intent(ProfileActivity.this, DashboardActivity.class);
                            intent.putExtra("PARENTS_NAME", parentName);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(ProfileActivity.this, "Failed to save profile!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}

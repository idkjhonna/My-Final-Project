package com.example.meowverse;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DashboardActivity extends AppCompatActivity {

    ImageView Catcare, Cattips, Catlove, Catfood;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        TextView nameTextView = findViewById(R.id.name);
        String parentsName = getIntent().getStringExtra("PARENTS_NAME");

        if (parentsName != null && !parentsName.isEmpty()) {
            nameTextView.setText("Hi, " + parentsName + "!");
        }
        Catcare = findViewById(R.id.catCareBtn);
        Cattips = findViewById(R.id.catTipsBtn);
        Catlove = findViewById(R.id.catLoveBtn);
        Catfood = findViewById(R.id.catFoodBtn);

        Catcare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, MainActivity4.class);
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Welcome to Cat Care!", Toast.LENGTH_SHORT).show();
            }
        });
        Cattips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, MainActivity3.class);
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Welcome to Cat Tips and Guide!", Toast.LENGTH_SHORT).show();
            }
        });

        Catlove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DashboardActivity.this, MainActivity5.class);
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Welcome to Cat Love!", Toast.LENGTH_SHORT).show();
            }
        });

        Catfood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, MainActivity6.class);
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Welcome to Cat Food and Recommendation!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}